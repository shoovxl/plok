#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ИС «УчётТ» — Информационная система учёта техники техникума
Веб-версия на Flask + SQLite
"""

from flask import Flask, render_template, request, redirect, url_for, flash, session, g
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import sqlite3
import os
from datetime import datetime, date

app = Flask(__name__)
app.secret_key = 'uchet-t-secret-key-2026-practice'
DATABASE = os.path.join(os.path.dirname(__file__), 'uchet.db')

# ---------- Database helpers ----------

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA foreign_keys = ON')
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    cur = db.cursor()

    cur.executescript('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fio TEXT NOT NULL,
        login TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'Оператор'  -- Администратор / Оператор / Просмотр
    );

    CREATE TABLE IF NOT EXISTS types (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL
    );

    CREATE TABLE IF NOT EXISTS cabinets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        number TEXT NOT NULL,
        name TEXT,
        building TEXT,
        responsible TEXT
    );

    CREATE TABLE IF NOT EXISTS equipment (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        inv_number TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        type_id INTEGER,
        model TEXT,
        manufacturer TEXT,
        date_received DATE,
        cost REAL,
        cabinet_id INTEGER,
        mol TEXT,
        status TEXT DEFAULT 'Исправно',  -- Исправно / В ремонте / Списано
        warranty_until DATE,
        note TEXT,
        FOREIGN KEY (type_id) REFERENCES types(id),
        FOREIGN KEY (cabinet_id) REFERENCES cabinets(id)
    );

    CREATE TABLE IF NOT EXISTS movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        equipment_id INTEGER NOT NULL,
        date TEXT NOT NULL,
        from_cabinet_id INTEGER,
        to_cabinet_id INTEGER NOT NULL,
        basis TEXT,
        user_id INTEGER,
        FOREIGN KEY (equipment_id) REFERENCES equipment(id),
        FOREIGN KEY (from_cabinet_id) REFERENCES cabinets(id),
        FOREIGN KEY (to_cabinet_id) REFERENCES cabinets(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS repairs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        equipment_id INTEGER NOT NULL,
        date_request TEXT NOT NULL,
        description TEXT,
        status TEXT DEFAULT 'Открыта',  -- Открыта / В работе / Выполнена
        date_done TEXT,
        work_done TEXT,
        cost REAL,
        FOREIGN KEY (equipment_id) REFERENCES equipment(id)
    );
    ''')

    # Seed data if empty
    if cur.execute('SELECT COUNT(*) FROM users').fetchone()[0] == 0:
        cur.execute(
            'INSERT INTO users (fio, login, password_hash, role) VALUES (?, ?, ?, ?)',
            ('Администратор Системы', 'admin', generate_password_hash('admin'), 'Администратор')
        )
        cur.execute(
            'INSERT INTO users (fio, login, password_hash, role) VALUES (?, ?, ?, ?)',
            ('Иванова Мария Петровна', 'operator', generate_password_hash('123'), 'Оператор')
        )
        cur.execute(
            'INSERT INTO users (fio, login, password_hash, role) VALUES (?, ?, ?, ?)',
            ('Петров Алексей', 'viewer', generate_password_hash('123'), 'Просмотр')
        )

        types = ['ПК', 'Ноутбук', 'Проектор', 'МФУ', 'Интерактивная доска', 'Принтер', 'Монитор', 'Сервер']
        for t in types:
            cur.execute('INSERT INTO types (name) VALUES (?)', (t,))

        cabinets = [
            ('101', 'Кабинет информатики', 'Корпус А', 'Смирнова Е.В.'),
            ('102', 'Лаборатория сетей', 'Корпус А', 'Козлов Д.А.'),
            ('205', 'Аудитория мультимедиа', 'Корпус Б', 'Васильева О.Н.'),
            ('301', 'Серверная', 'Корпус А', 'IT-отдел'),
            ('Склад', 'Склад техники', 'Корпус В', 'Хозяйственная часть'),
        ]
        for c in cabinets:
            cur.execute('INSERT INTO cabinets (number, name, building, responsible) VALUES (?, ?, ?, ?)', c)

        equipment = [
            ('Т-001', 'Системный блок', 1, 'Office PC-2024', 'DEXP', '2024-09-01', 45000, 1, 'Смирнова Е.В.', 'Исправно', '2027-09-01', ''),
            ('Т-002', 'Монитор 24"', 7, 'S24R350', 'Samsung', '2024-09-01', 12000, 1, 'Смирнова Е.В.', 'Исправно', '2027-09-01', ''),
            ('Т-003', 'Ноутбук', 2, 'IdeaPad 3', 'Lenovo', '2025-02-15', 55000, 2, 'Козлов Д.А.', 'Исправно', '2028-02-15', ''),
            ('Т-004', 'Проектор', 3, 'EB-X49', 'Epson', '2023-11-20', 38000, 3, 'Васильева О.Н.', 'Исправно', '2026-11-20', ''),
            ('Т-005', 'МФУ', 4, 'LaserJet Pro MFP', 'HP', '2024-03-10', 28000, 1, 'Смирнова Е.В.', 'В ремонте', '2027-03-10', 'Замена картриджа'),
            ('Т-006', 'Интерактивная доска', 5, 'SMART Board 6065', 'SMART', '2022-08-01', 180000, 3, 'Васильева О.Н.', 'Исправно', '2025-08-01', ''),
            ('Т-007', 'Сервер', 8, 'PowerEdge R740', 'Dell', '2021-05-12', 320000, 4, 'IT-отдел', 'Исправно', '2026-05-12', ''),
            ('Т-008', 'Принтер', 6, 'L3250', 'Epson', '2025-01-20', 18000, 2, 'Козлов Д.А.', 'Исправно', '2028-01-20', ''),
            ('Т-009', 'Системный блок', 1, 'Office PC-2023', 'IRU', '2023-09-05', 42000, 1, 'Смирнова Е.В.', 'Исправно', '2026-09-05', ''),
            ('Т-010', 'Ноутбук', 2, 'VivoBook 15', 'ASUS', '2024-10-01', 48000, 5, 'Хозяйственная часть', 'Исправно', '2027-10-01', 'На складе'),
        ]
        for e in equipment:
            cur.execute('''INSERT INTO equipment 
                (inv_number, name, type_id, model, manufacturer, date_received, cost, cabinet_id, mol, status, warranty_until, note)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', e)

        cur.execute('''INSERT INTO movements (equipment_id, date, from_cabinet_id, to_cabinet_id, basis, user_id)
                       VALUES (10, '2025-09-15', 1, 5, 'Приказ №45 о передаче на склад', 1)''')
        cur.execute('''INSERT INTO repairs (equipment_id, date_request, description, status, date_done, work_done, cost)
                       VALUES (5, '2026-10-10', 'Не печатает, ошибка картриджа', 'В работе', NULL, NULL, NULL)''')
        cur.execute('''INSERT INTO repairs (equipment_id, date_request, description, status, date_done, work_done, cost)
                       VALUES (4, '2026-09-01', 'Замена лампы', 'Выполнена', '2026-09-05', 'Заменена лампа, калибровка', 4500)''')

    db.commit()
    db.close()

# ---------- Auth ----------

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Войдите в систему', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get('role') != 'Администратор':
            flash('Доступ только для администратора', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login_ = request.form.get('login', '').strip()
        password = request.form.get('password', '')
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE login = ?', (login_,)).fetchone()
        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['fio'] = user['fio']
            session['role'] = user['role']
            flash(f'Добро пожаловать, {user["fio"]}!', 'success')
            return redirect(url_for('index'))
        flash('Неверный логин или пароль', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('login'))

# ---------- Main pages ----------

@app.route('/')
@login_required
def index():
    db = get_db()
    stats = {
        'total': db.execute('SELECT COUNT(*) FROM equipment WHERE status != "Списано"').fetchone()[0],
        'repair': db.execute('SELECT COUNT(*) FROM equipment WHERE status = "В ремонте"').fetchone()[0],
        'cabinets': db.execute('SELECT COUNT(*) FROM cabinets').fetchone()[0],
        'open_repairs': db.execute('SELECT COUNT(*) FROM repairs WHERE status != "Выполнена"').fetchone()[0],
    }
    recent = db.execute('''
        SELECT e.inv_number, e.name, e.status, c.number as cabinet
        FROM equipment e LEFT JOIN cabinets c ON e.cabinet_id = c.id
        ORDER BY e.id DESC LIMIT 5
    ''').fetchall()
    return render_template('index.html', stats=stats, recent=recent)

# ---------- Equipment ----------

@app.route('/equipment')
@login_required
def equipment_list():
    db = get_db()
    q = request.args.get('q', '').strip()
    status = request.args.get('status', '')
    cabinet = request.args.get('cabinet', '')

    sql = '''
        SELECT e.*, t.name as type_name, c.number as cabinet_number
        FROM equipment e
        LEFT JOIN types t ON e.type_id = t.id
        LEFT JOIN cabinets c ON e.cabinet_id = c.id
        WHERE 1=1
    '''
    params = []
    if q:
        sql += ' AND (e.inv_number LIKE ? OR e.name LIKE ? OR e.model LIKE ?)'
        params.extend([f'%{q}%'] * 3)
    if status:
        sql += ' AND e.status = ?'
        params.append(status)
    if cabinet:
        sql += ' AND e.cabinet_id = ?'
        params.append(cabinet)
    sql += ' ORDER BY e.inv_number'

    items = db.execute(sql, params).fetchall()
    cabinets = db.execute('SELECT * FROM cabinets ORDER BY number').fetchall()
    return render_template('equipment_list.html', items=items, cabinets=cabinets, q=q, status=status, cabinet=cabinet)

@app.route('/equipment/add', methods=['GET', 'POST'])
@login_required
def equipment_add():
    if session.get('role') == 'Просмотр':
        flash('Нет прав на добавление', 'danger')
        return redirect(url_for('equipment_list'))
    db = get_db()
    if request.method == 'POST':
        try:
            db.execute('''INSERT INTO equipment 
                (inv_number, name, type_id, model, manufacturer, date_received, cost, cabinet_id, mol, status, warranty_until, note)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (
                    request.form['inv_number'].strip(),
                    request.form['name'].strip(),
                    request.form.get('type_id') or None,
                    request.form.get('model'),
                    request.form.get('manufacturer'),
                    request.form.get('date_received') or None,
                    float(request.form['cost']) if request.form.get('cost') else None,
                    request.form.get('cabinet_id') or None,
                    request.form.get('mol'),
                    request.form.get('status', 'Исправно'),
                    request.form.get('warranty_until') or None,
                    request.form.get('note'),
                ))
            db.commit()
            flash('Техника успешно добавлена', 'success')
            return redirect(url_for('equipment_list'))
        except sqlite3.IntegrityError:
            flash('Инвентарный номер уже существует', 'danger')
    types = db.execute('SELECT * FROM types ORDER BY name').fetchall()
    cabinets = db.execute('SELECT * FROM cabinets ORDER BY number').fetchall()
    return render_template('equipment_form.html', item=None, types=types, cabinets=cabinets, title='Добавление техники')

@app.route('/equipment/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def equipment_edit(id):
    if session.get('role') == 'Просмотр':
        flash('Нет прав на редактирование', 'danger')
        return redirect(url_for('equipment_list'))
    db = get_db()
    item = db.execute('SELECT * FROM equipment WHERE id = ?', (id,)).fetchone()
    if not item:
        flash('Запись не найдена', 'danger')
        return redirect(url_for('equipment_list'))
    if request.method == 'POST':
        db.execute('''UPDATE equipment SET
            inv_number=?, name=?, type_id=?, model=?, manufacturer=?, date_received=?,
            cost=?, cabinet_id=?, mol=?, status=?, warranty_until=?, note=?
            WHERE id=?''',
            (
                request.form['inv_number'].strip(),
                request.form['name'].strip(),
                request.form.get('type_id') or None,
                request.form.get('model'),
                request.form.get('manufacturer'),
                request.form.get('date_received') or None,
                float(request.form['cost']) if request.form.get('cost') else None,
                request.form.get('cabinet_id') or None,
                request.form.get('mol'),
                request.form.get('status', 'Исправно'),
                request.form.get('warranty_until') or None,
                request.form.get('note'),
                id,
            ))
        db.commit()
        flash('Данные обновлены', 'success')
        return redirect(url_for('equipment_list'))
    types = db.execute('SELECT * FROM types ORDER BY name').fetchall()
    cabinets = db.execute('SELECT * FROM cabinets ORDER BY number').fetchall()
    return render_template('equipment_form.html', item=item, types=types, cabinets=cabinets, title='Редактирование техники')

# ---------- Cabinets ----------

@app.route('/cabinets')
@login_required
def cabinets_list():
    db = get_db()
    items = db.execute('''
        SELECT c.*, COUNT(e.id) as eq_count
        FROM cabinets c
        LEFT JOIN equipment e ON e.cabinet_id = c.id AND e.status != 'Списано'
        GROUP BY c.id
        ORDER BY c.number
    ''').fetchall()
    return render_template('cabinets.html', items=items)

@app.route('/cabinets/add', methods=['GET', 'POST'])
@login_required
def cabinets_add():
    if session.get('role') == 'Просмотр':
        flash('Нет прав', 'danger')
        return redirect(url_for('cabinets_list'))
    if request.method == 'POST':
        db = get_db()
        db.execute('INSERT INTO cabinets (number, name, building, responsible) VALUES (?, ?, ?, ?)',
                   (request.form['number'], request.form.get('name'), request.form.get('building'), request.form.get('responsible')))
        db.commit()
        flash('Кабинет добавлен', 'success')
        return redirect(url_for('cabinets_list'))
    return render_template('cabinet_form.html', item=None)

# ---------- Movements ----------

@app.route('/movements')
@login_required
def movements_list():
    db = get_db()
    items = db.execute('''
        SELECT m.*, e.inv_number, e.name as eq_name,
               cf.number as from_cab, ct.number as to_cab, u.fio
        FROM movements m
        JOIN equipment e ON m.equipment_id = e.id
        LEFT JOIN cabinets cf ON m.from_cabinet_id = cf.id
        LEFT JOIN cabinets ct ON m.to_cabinet_id = ct.id
        LEFT JOIN users u ON m.user_id = u.id
        ORDER BY m.date DESC, m.id DESC
    ''').fetchall()
    return render_template('movements.html', items=items)

@app.route('/movements/add', methods=['GET', 'POST'])
@login_required
def movements_add():
    if session.get('role') == 'Просмотр':
        flash('Нет прав', 'danger')
        return redirect(url_for('movements_list'))
    db = get_db()
    if request.method == 'POST':
        eq_id = request.form['equipment_id']
        to_cab = request.form['to_cabinet_id']
        eq = db.execute('SELECT cabinet_id FROM equipment WHERE id = ?', (eq_id,)).fetchone()
        from_cab = eq['cabinet_id'] if eq else None
        db.execute('''INSERT INTO movements (equipment_id, date, from_cabinet_id, to_cabinet_id, basis, user_id)
                      VALUES (?, ?, ?, ?, ?, ?)''',
                   (eq_id, request.form.get('date') or date.today().isoformat(), from_cab, to_cab,
                    request.form.get('basis'), session['user_id']))
        db.execute('UPDATE equipment SET cabinet_id = ? WHERE id = ?', (to_cab, eq_id))
        db.commit()
        flash('Перемещение оформлено', 'success')
        return redirect(url_for('movements_list'))
    equipment = db.execute('SELECT id, inv_number, name FROM equipment WHERE status != "Списано" ORDER BY inv_number').fetchall()
    cabinets = db.execute('SELECT * FROM cabinets ORDER BY number').fetchall()
    return render_template('movement_form.html', equipment=equipment, cabinets=cabinets)

# ---------- Repairs ----------

@app.route('/repairs')
@login_required
def repairs_list():
    db = get_db()
    items = db.execute('''
        SELECT r.*, e.inv_number, e.name as eq_name
        FROM repairs r
        JOIN equipment e ON r.equipment_id = e.id
        ORDER BY CASE r.status WHEN 'Открыта' THEN 0 WHEN 'В работе' THEN 1 ELSE 2 END, r.date_request DESC
    ''').fetchall()
    return render_template('repairs.html', items=items)

@app.route('/repairs/add', methods=['GET', 'POST'])
@login_required
def repairs_add():
    if session.get('role') == 'Просмотр':
        flash('Нет прав', 'danger')
        return redirect(url_for('repairs_list'))
    db = get_db()
    if request.method == 'POST':
        eq_id = request.form['equipment_id']
        db.execute('''INSERT INTO repairs (equipment_id, date_request, description, status)
                      VALUES (?, ?, ?, 'Открыта')''',
                   (eq_id, request.form.get('date_request') or date.today().isoformat(), request.form.get('description')))
        db.execute('UPDATE equipment SET status = "В ремонте" WHERE id = ?', (eq_id,))
        db.commit()
        flash('Заявка на ремонт создана', 'success')
        return redirect(url_for('repairs_list'))
    equipment = db.execute('SELECT id, inv_number, name FROM equipment WHERE status = "Исправно" ORDER BY inv_number').fetchall()
    return render_template('repair_form.html', equipment=equipment, item=None)

@app.route('/repairs/<int:id>/done', methods=['POST'])
@login_required
def repairs_done(id):
    if session.get('role') == 'Просмотр':
        flash('Нет прав', 'danger')
        return redirect(url_for('repairs_list'))
    db = get_db()
    repair = db.execute('SELECT * FROM repairs WHERE id = ?', (id,)).fetchone()
    if repair:
        db.execute('''UPDATE repairs SET status='Выполнена', date_done=?, work_done=?, cost=? WHERE id=?''',
                   (request.form.get('date_done') or date.today().isoformat(),
                    request.form.get('work_done'), float(request.form['cost']) if request.form.get('cost') else None, id))
        db.execute('UPDATE equipment SET status="Исправно" WHERE id=?', (repair['equipment_id'],))
        db.commit()
        flash('Ремонт отмечен как выполненный', 'success')
    return redirect(url_for('repairs_list'))

# ---------- Reports ----------

@app.route('/reports')
@login_required
def reports():
    return render_template('reports.html')

@app.route('/reports/by_cabinet')
@login_required
def report_by_cabinet():
    db = get_db()
    rows = db.execute('''
        SELECT c.number, c.name, c.building, e.inv_number, e.name as eq_name, e.model, e.status, t.name as type_name
        FROM cabinets c
        LEFT JOIN equipment e ON e.cabinet_id = c.id AND e.status != 'Списано'
        LEFT JOIN types t ON e.type_id = t.id
        ORDER BY c.number, e.inv_number
    ''').fetchall()
    return render_template('report_by_cabinet.html', rows=rows)

@app.route('/reports/warranty')
@login_required
def report_warranty():
    db = get_db()
    rows = db.execute('''
        SELECT e.inv_number, e.name, e.model, e.warranty_until, e.status, c.number as cabinet
        FROM equipment e
        LEFT JOIN cabinets c ON e.cabinet_id = c.id
        WHERE e.warranty_until IS NOT NULL AND e.status != 'Списано'
        ORDER BY e.warranty_until
    ''').fetchall()
    return render_template('report_warranty.html', rows=rows)

@app.route('/reports/broken')
@login_required
def report_broken():
    db = get_db()
    rows = db.execute('''
        SELECT e.inv_number, e.name, e.model, e.status, c.number as cabinet, r.description, r.date_request
        FROM equipment e
        LEFT JOIN cabinets c ON e.cabinet_id = c.id
        LEFT JOIN repairs r ON r.equipment_id = e.id AND r.status != 'Выполнена'
        WHERE e.status = 'В ремонте'
        ORDER BY e.inv_number
    ''').fetchall()
    return render_template('report_broken.html', rows=rows)

# ---------- Init ----------

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
